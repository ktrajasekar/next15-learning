export interface User {
    id: number;
    first_name: string;
    email: string;
    phone: string;
    date_of_birth: string;
    created_at: string;
}
