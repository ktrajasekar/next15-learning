export default function LoginPage() {
    return (
        <div style={{ padding: '20px', minHeight: '90vh' }}>
            <h1>Login</h1>
        </div>
    );
}
